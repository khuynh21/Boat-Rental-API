const http = require("http");
const mysql = require("mysql2");
const sailor = require("./lib/sailor");
const reserves = require("./lib/reserves");
const boat = require("./lib/boat");

// Set up the MySQL database connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "cricket1",
  multipleStatements: true
  
});

const createDB = `CREATE DATABASE IF NOT EXISTS SailingAdventure;`

const SQLsetup = `

USE SailingAdventure;

CREATE TABLE IF NOT EXISTS Sailors (
  S_Id INT AUTO_INCREMENT PRIMARY KEY,
  S_name VARCHAR(50) NOT NULL,
  B_date DATE NOT NULL,
  Rate INT NOT NULL
);

CREATE TABLE IF NOT EXISTS Boats (
  B_Id INT AUTO_INCREMENT PRIMARY KEY,
  B_name VARCHAR(50) NOT NULL,
  B_type VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Reserves (
  S_Id INT,
  B_Id INT,
  Day DATE,
  PRIMARY KEY (S_Id, B_Id, Day),
  FOREIGN KEY (S_Id) REFERENCES Sailors(S_Id),
  FOREIGN KEY (B_Id) REFERENCES Boats(B_Id)
);

`

db.query(SQLsetup, (err)=>{
    if (err){
      console.error("SQL cannot be setup");
    }
    else{
      console.log("Database is running!");
    }
});

// Request handler
const requestHandler = (req, res) => {
  const baseURL = `http://${req.headers.host}/`;
  const parsedURL = new URL(req.url, baseURL);
  const pathname = parsedURL.pathname;
  const method = req.method;

  const urlQuery = parsedURL.searchParams;
  const entries = urlQuery.entries();
  const query = Object.fromEntries(entries);

  switch (method) {
    case "POST":
      if (pathname === "/sailor" || pathname === "/sailor/") {
        sailor.addSailor(db, query, (statusCode, resStr, resMsg) => {
          res.writeHead(statusCode, { "Content-Type": "text/plain" });
          res.end(resMsg);
        });
      } else if (pathname === "/reserves" || pathname === "/reserves/") {
        reserves.addReservation(db, query, (statusCode, resStr, resMsg) => {
          res.writeHead(statusCode, { "Content-Type": "text/plain" });
          res.end(resMsg);
        });

      } else if(pathname === "/boat" || pathname === "/boat/"){

        boat.addBoat(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);
        });
      }
      else {
        res.writeHead(404, { "Content-Type": "text/plain" });
        res.end("Invalid endpoint.");
      }
      break;

    case "GET":
      if (pathname === "/sailor" || pathname === "/sailor/"){
        sailor.listSailors(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);
        });
      }else if (pathname ==="/reserves" || pathname === "/reserves/"){

        reserves.listReservations(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg)
        });

      }else if (pathname === "/boat" || pathname === "/boat/"){

        boat.listBoats(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);
        });

      }
      else{
        res.writeHead(404, {"Content-Type" : "text/plain"});
        res.end("Invalid Endpoint");
      }
      break;
    
    case "PUT":
      if (pathname ==="/sailor" || pathname==="/sailor/"){

        const {S_Id,S_name, B_date, Rate } = query;

        if (!S_Id || !S_name ||!B_date ||!Rate){
          res.writeHead(400, {"Content-Type":"text/plain"});
          res.end("Record Not Found");
          return;
        }
        query.S_Id = S_Id;

        sailor.updateSailor(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);
        });

    } else if(pathname === '/boat' || pathname === '/boat/'){
      const {B_Id, B_name, B_type} = query

      if (!B_Id||!B_name||!B_type){
        res.writeHead(400, {"Content-Type":"text/plain"});
        res.end("Missing Boat ID");
        return;
      }
      boat.updateBoat(db, query, (statusCode, resStr, resMsg)=>{
        res.writeHead(statusCode, {"Content-Type": "text/plain"});
        res.end(resMsg);
      });
    }else{
      res.writeHead(404, {"Content-Type": "text/plain"});
      res.end(`${pathname} is an invalid endpoint for method: PUT`); // Debugging

    }
      break;

    case "DELETE":
      if(pathname === "/sailor" || pathname==="/sailor/"){
        const {S_Id} = query;
        if(!S_Id){
          res.writeHead(400, {"Content-Type": "text/plain"});
          res.end("Missing Sailor ID.");
          return;
        }
        query.S_Id = S_Id;
        sailor.deleteSailor(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);
        });

      }else if(pathname === '/reserves' || pathname === '/reserves/'){

        const { S_Id, B_Id, Day} = query;

        if(!S_Id || !B_Id || !Day){
          res.writeHead(400, {"Content-Type": "text/plain"});
          res.end(resMsg);
          return;
        }
        reserves.deleteReservation(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type": "text/plain"});
          res.end(resMsg);
        });
      
      
      }else if(pathname==='/boat' || pathname==='/boat/'){

        const {B_Id} = query

        if(!B_Id){
          res.writeHead(400, {"Content-Type": "text/plain"});
          res.end("Missing Boat ID");
          return;
        }
        boat.deleteBoat(db, query, (statusCode, resStr, resMsg)=>{
          res.writeHead(statusCode, {"Content-Type":"text/plain"});
          res.end(resMsg);

        });
        
        

      }else{
        res.writeHead(404, {"Content-Type":"text/plain"});
        res.end("Invalid EndPoint");
      }
      break;

    default:
      res.writeHead(405, { "Content-Type": "text/plain" });
      res.end("Method not allowed.");
  }
};

// Start the server dynamically without specifying an IP address
const port = 3000;
const server = http.createServer(requestHandler);
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

